# Installation
> `npm install --save @types/js-yaml`

# Summary
This package contains type definitions for js-yaml (https://github.com/nodeca/js-yaml).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/js-yaml.

### Additional Details
 * Last updated: Thu, 25 Jun 2020 02:29:19 GMT
 * Dependencies: none
 * Global values: `jsyaml`

# Credits
These definitions were written by [Bart van der Schoor](https://github.com/Bartvds), [Sebastian Clausen](https://github.com/sclausen), and [ExE Boss](https://github.com/ExE-Boss).
