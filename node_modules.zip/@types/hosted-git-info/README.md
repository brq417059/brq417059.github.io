# Installation
> `npm install --save @types/hosted-git-info`

# Summary
This package contains type definitions for hosted-git-info (https://github.com/npm/hosted-git-info).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hosted-git-info

Additional Details
 * Last updated: Thu, 01 Nov 2018 23:10:57 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Jason <https://github.com/OiyouYeahYou>.
