# Installation
> `npm install --save @types/debug`

# Summary
This package contains type definitions for debug (https://github.com/visionmedia/debug).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/debug

Additional Details
 * Last updated: Thu, 08 Aug 2019 15:58:41 GMT
 * Dependencies: none
 * Global values: debug

# Credits
These definitions were written by Seon-Wook Park <https://github.com/swook>, Gal Talmor <https://github.com/galtalmor>, John McLaughlin <https://github.com/zamb3zi>, Brasten Sager <https://github.com/brasten>, Nicolas Penin <https://github.com/npenin>, and Kristian Brünn <https://github.com/kristianmitk>.
