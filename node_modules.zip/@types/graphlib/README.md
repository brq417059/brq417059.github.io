# Installation
> `npm install --save @types/graphlib`

# Summary
This package contains type definitions for graphlib (https://github.com/cpettitt/graphlib).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/graphlib.

### Additional Details
 * Last updated: Thu, 20 Aug 2020 11:31:31 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Dan Vanderkam](http://danvk.org/), and [Dan Mironenko](wolfson@bracketedrebels.com).
