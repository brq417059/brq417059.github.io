# `@leancloud/adapters-superagent`

> TODO: description

## Usage

```
const adaptersSuperagent = require('@leancloud/adapters-superagent');

// TODO: DEMONSTRATE API
```
