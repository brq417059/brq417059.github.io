import { Adapters } from "@leancloud/adapter-types";
export declare const request: Adapters["request"];
export declare const upload: Adapters["upload"];
