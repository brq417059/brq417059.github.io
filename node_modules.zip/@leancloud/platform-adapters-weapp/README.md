# `@leancloud/platform-adapters-weapp`

## Usage

```
import AV from 'leancloud-storage';
import * as adapters from '@leancloud/platform-adapters-weapp';

AV.setAdapters(adapters);
```
