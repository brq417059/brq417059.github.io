import { Adapters } from "@leancloud/adapter-types";
export declare const storage: Adapters["storage"];
