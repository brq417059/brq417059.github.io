import { Adapters } from "@leancloud/adapter-types";
export declare const WebSocket: Adapters["WebSocket"];
