# `@leancloud/adapters-browser`

## Usage

```
import AV from 'leancloud-storage';
import * as adapters from '@leancloud/adapters-browser';

AV.setAdapters(adapters);
```
