import { Adapters } from "@leancloud/adapter-types";
export declare const platformInfo: Adapters["platformInfo"];
export declare const WebSocket: Adapters["WebSocket"];
export declare const storage: Adapters["storage"];
export { request, upload } from "@leancloud/adapters-superagent";
