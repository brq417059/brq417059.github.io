# `@leancloud/adapter-types`

## Usage

```
import type { Adaptors } from '@leancloud/adapter-types';
```
