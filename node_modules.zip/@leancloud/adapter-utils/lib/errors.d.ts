export declare class AbortError extends Error {
    name: string;
}
