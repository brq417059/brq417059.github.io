# `@leancloud/adapter-utils`

## Usage

```
const adapterUtils = require('@leancloud/adapter-utils');
```
