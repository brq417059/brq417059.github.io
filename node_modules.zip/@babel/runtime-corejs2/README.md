# @babel/runtime-corejs2

> babel's modular runtime helpers with core-js@2 polyfilling

See our website [@babel/runtime-corejs2](https://babeljs.io/docs/en/babel-runtime-corejs2) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/runtime-corejs2
```

or using yarn:

```sh
yarn add @babel/runtime-corejs2 --dev
```
