"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.legacyCommon = exports.legacyMonitor = exports.legacyPlugin = void 0;
const legacy_1 = require("./legacy");
Object.defineProperty(exports, "legacyPlugin", { enumerable: true, get: function () { return legacy_1.plugin; } });
Object.defineProperty(exports, "legacyMonitor", { enumerable: true, get: function () { return legacy_1.monitor; } });
Object.defineProperty(exports, "legacyCommon", { enumerable: true, get: function () { return legacy_1.common; } });
//# sourceMappingURL=index.js.map