![Snyk logo](https://snyk.io/style/asset/logo/snyk-print.svg)

---

[![Known Vulnerabilities](https://snyk.io/test/github/snyk/cocoapods-lockfile-parser/badge.svg)](https://snyk.io/test/github/snyk/cocoapods-lockfile-parser)

Snyk helps you find, fix and monitor for known vulnerabilities in your dependencies, both on an ad hoc basis and as part of your CI (Build) system.

## Snyk cocoapods-lockfile-parser

Generate a Snyk dependency graph from a Podfile.lock file
